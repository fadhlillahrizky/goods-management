<?php $__env->startSection('content'); ?>
    <h1>Edit Data Barang</h1>
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
           <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row">
        <div class="col-lg-12">
        <form action="/barang/<?php echo e($barang->id); ?>/update" method="POST" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>    
            <div class="form-group">
                <label for="exampleInputEmail1">Nama Barang</label>
                <input name="NamaBarang" type="text" class="form-control" id="exampleInputEmail1" placeholder="Nama Barang" value="<?php echo e($barang->NamaBarang); ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Harga Beli</label>
                <input name="HargaBeli" type="text" class="form-control" id="exampleInputEmail1" placeholder="Harga Beli" value="<?php echo e($barang->HargaBeli); ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputEmail1">Harga Jual</label>
                <input name="HargaJual" type="integer" class="form-control" id="exampleInputEmail1" placeholder="Harga Jual" value="<?php echo e($barang->HargaJual); ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputPassword1">Stok</label>
                <input name="Stok" type="integer" class="form-control" id="exampleInputPassword1" placeholder="Stok" value="<?php echo e($barang->Stok); ?>">
            </div>
            <div class="input-group">
                <div class="custom-file">
                    <input name="FotoBarang" type="file" class="custom-file-input">
                    <label class="custom-file-label">Choose file</label>
                </div>
            </div>  
                <button type="submit" class="btn btn-primary">Update</button>               
            </form>
            </div>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\goods-management\resources\views/goods/edit.blade.php ENDPATH**/ ?>